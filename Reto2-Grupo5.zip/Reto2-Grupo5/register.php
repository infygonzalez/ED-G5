<?php

include("cone_bd.php");

if ($conex) {
    echo "";
}

?>