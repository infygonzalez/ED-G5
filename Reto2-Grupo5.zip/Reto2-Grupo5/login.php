<?php
session_start();
include("register.php");

// Comprobar conexión
if ($conex->connect_error) {
    die("Fallo en la conexión: " . $conex->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';

    // Preparar la consulta segura
    $sql = "SELECT Nombre, Contrasena FROM AgenciaViajes WHERE Nombre = '$nombre' AND Contrasena = '$contrasena'";
    $resultado = $conex->query($sql);
    if ($resultado->num_rows > 0) {
        $_SESSION['nombre'] = $nombre;
        header("Location: inicio.php");
    }
    else {
        header("Location: login.php?error=1");
    }
    
}
$conex->close();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Viajes Erreka-Mari</title>
    <link rel="stylesheet" href="Login.css">
    <link rel="icon" type="image/png" href="img/Logo Reto 2.png">
</head>
<body>

    <!-------------------------HEADER--------------------------------->
    <header>
        <img class="logoimg" src="img/Logo_Reto_2-sinfondo.png">
    </header>

    <!-------------------------MAIN--------------------------------->
    <main>
        <div class="login-container">
            <div class="login-form">
                <h1>¡Bienvenido a TravelFive!</h1>
                <p>Accede a tu cuenta para explorar el mundo</p>
                <form method="POST">

                <?php if (isset($_GET['error'])): ?>
                    <p style="color: red;">Usuario o contraseña incorrectos</p>
                <?php endif; ?>

                    <div class="input-group">
                        <label for="nombre">Usuario</label>
                        <input type="text" id="nombre" name="nombre" required>
                    </div>
                    <div class="input-group">
                        <label for="contrasena">Contraseña</label>
                        <input type="password" id="contrasena" name="contrasena" required>
                    </div>
                    <button type="submit" class="btn">Iniciar Sesión</button>
                </form>
            </div>
        </div>
    </main>

    <!-------------------------SCRIPT--------------------------------->
    <script>
        const images = [
            "img/el-cairo1.jpg",
            "img/Miami.jpg",
            "img/Pekin.jpg",
            "img/sao-paulo-.png",
            "img/Viena.jpg",
        ];

        let currentIndex = 0;

        function changeBackground() {
            document.body.style.backgroundImage = `url(${images[currentIndex]})`;
            currentIndex = (currentIndex + 1) % images.length;
        }

        setInterval(changeBackground, 5000);
        changeBackground();
    </script>

</body>
</html>