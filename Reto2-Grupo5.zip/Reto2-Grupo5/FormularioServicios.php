<?php
session_start();
include("register.php");

$nombre_usuario = $_SESSION['nombre'] ?? null; 
$nombre_usuario = mysqli_real_escape_string($conex, $nombre_usuario);

// Verificar conexión
if (!isset($conex) || $conex->connect_error) {
    die("Conexión fallida: " . $conex->connect_error);
}

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_servicio'])) {
    if (isset($_POST['servicio'])) {
        $tipo_servicio = $_POST['servicio'];

        switch ($tipo_servicio) {
            case 'vuelos':
                $mensaje = procesarVuelo($conex);
                break;
            case 'hospedaje':
                $mensaje = procesarAlojamiento($conex);
                break;
            case 'Otros':
                $mensaje = procesarOtros($conex);
                break;
            default:
                $mensaje = "Error: Tipo de servicio no válido.";
        }
    } else {
        $mensaje = "Error: No se ha especificado el tipo de servicio.";
    }
}

// Función para procesar los datos de vuelos--------------------------------------------------------------------------------------------------------------------
function procesarVuelo($conex) {
    $required_fields = ['AeropuertoOrigen', 'AeropuertoDestino', 'ID_VueloIda', 'Aerolinea', 'Precio', 'FechaSalida', 'HoraSalida', 'Duracion'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $error_msg = "Error: El campo $field es obligatorio para vuelos.";
            echo "<script>alert('$error_msg');</script>";
            return;
        }
    }

    $AeropuertoOrigen = trim($_POST['AeropuertoOrigen']);
    $AeropuertoDestino = trim($_POST['AeropuertoDestino']);
    $ID_VueloIda = trim($_POST['ID_VueloIda']);
    $Aerolinea = trim($_POST['Aerolinea']);
    $Precio = trim($_POST['Precio']);
    $FechaSalida = trim($_POST['FechaSalida']);
    $HoraSalida = trim($_POST['HoraSalida']);
    $Duracion = trim($_POST['Duracion']);

    // Verificar si la aerolínea existe antes de insertar
    $check_sql = "SELECT ID_aerolinea FROM aerolinea WHERE ID_aerolinea = ?";
    $stmt_check = $conex->prepare($check_sql);
    $stmt_check->bind_param("s", $Aerolinea);
    $stmt_check->execute();
    $stmt_check->store_result();
    
    if ($stmt_check->num_rows == 0) {
        echo "<script>alert('Error: La aerolínea especificada no existe.');</script>";
        return;
    }
    $stmt_check->close();

    $sql = "INSERT INTO VueloIda (ID_VueloIda, IdViajes, AeropuertoOrigen, AeropuertoDestino, Precio, Aerolinea, FechaSalida, HoraSalida, Duracion) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conex->prepare($sql);
    if (!$stmt) {
        echo "<script>alert('Error en la preparación de la consulta: {$conex->error}');</script>";
        return;
    }
    
    $IdViajes = 'V001';
    $stmt->bind_param("ssssdssss", $ID_VueloIda, $IdViajes, $AeropuertoOrigen, $AeropuertoDestino, $Precio, $Aerolinea, $FechaSalida, $HoraSalida, $Duracion);
    
    if ($stmt->execute()) {
        echo "<script>alert('Nuevo vuelo agregado exitosamente.');</script>";
    } else {
        echo "<script>alert('Error en la ejecución de la consulta: {$stmt->error}');</script>";
    }
    $stmt->close();
}
// Función para procesar los datos de alojamiento-------------------------------------------------------------------------------------------------------------------
function procesarAlojamiento($conex) {
    $required_fields = ['NombreHotel', 'Ciudad', 'Precio', 'FechaEntrada', 'FechaSalida', 'TipoHab'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $error_msg = "Error: El campo $field es obligatorio para alojamiento.";
            echo "<script>alert('$error_msg');</script>";
            return;
        }
    }

    $NombreHotel = trim($_POST['NombreHotel']);
    $Ciudad = trim($_POST['Ciudad']);
    $Precio = trim($_POST['Precio']);
    $FechaEntrada = trim($_POST['FechaEntrada']);
    $FechaSalida = trim($_POST['FechaSalida']);
    $TipoHab = trim($_POST['TipoHab']);

    $sql = "INSERT INTO Alojamiento (IdAlojamiento, NombreHotel, Ciudad, Precio, FechaEntrada, FechaSalida, TipoHab, IdEventos) 
            VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conex->prepare($sql);
    if (!$stmt) {
        $error_msg = "Error en la preparación de la consulta: " . $conex->error;
        echo "<script>alert('$error_msg');</script>";
        return;
    }
    
    $IdEventos = 'E001';
    $stmt->bind_param("ssdssss", $NombreHotel, $Ciudad, $Precio, $FechaEntrada, $FechaSalida, $TipoHab, $IdEventos);
    
    if ($stmt->execute()) {
        $stmt->close();
        $exito_msg = "Nuevo alojamiento agregado exitosamente.";
        echo "<script>alert('$exito_msg');</script>";
    } else {
        $stmt->close();     
        $error_msg = "Error en la ejecución de la consulta: " . $stmt->error;
        echo "<script>alert('$error_msg');</script>";
    }
}

// Función para procesar los datos de otros servicios----------------------------------------------------------------------------------------------------------------
function procesarOtros($conex) {
    $required_fields = ['Nombre', 'Fecha', 'Descripcion', 'Precio'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $error_msg = "Error: El campo $field es obligatorio para otros servicios." . $conex->error;
            echo "<script>alert('$error_msg');</script>";
        }
    }

    $Nombre = trim($_POST['Nombre']);
    $Fecha = trim($_POST['Fecha']);
    $Descripcion = trim($_POST['Descripcion']);
    $Precio = trim($_POST['Precio']);

    $sql = "INSERT INTO Eventos (IdEventos, Descripcion, Tipo, Nombre, IdViajes) 
            VALUES (UUID(), ?, 'Otros', ?, ?)";
    
    $stmt = $conex->prepare($sql);
    if (!$stmt) {
        $error_msg = "Error en la preparación de la consulta: " . $conex->error;
        echo "<script>alert('$error_msg');</script>";
    }
    
    $IdViajes = 'V001';
    $stmt->bind_param("sss", $Descripcion, $Nombre, $IdViajes);
    
    if ($stmt->execute()) {
        $stmt->close();
        $exito_msg = "Nuevo servicio agregado exitosamente.";
        echo "<script>alert('$exito_msg');</script>";
    } else {
        $stmt->close();
        $error_msg = "Error en la ejecución de la consulta: " . $stmt->error;
        echo "<script>alert('$error_msg');</script>";
    }
}
?>


<!-------------------------------HTML-------------------------------->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Servicios</title>
    <link rel="stylesheet" href="Servicios.css">
    <style>
        /* Estilos para los mensajes */
        .mensaje {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .mensaje-exito {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .mensaje-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <!-- ----------------------Header------------------------------>
    <header>
        <div class="logo"> <img class="logoimg" src="img/Logo_Reto_2-sinfondo.png"></div>
        <div><h1>Viajes Erreka-Mari</h1></div>
        <nav class="menu">
            <ul>
                <li><a>Formulario de Servicios</a></li>
            </ul>
        </nav>
    </header>

    <!-- ----------------------Main------------------------------>
    <main>
        <!-- Sección principal-->
        <section>
            <div class="form-container">
                <form class="form">
                    <div class="form-group">
                        <label for="tipo-viaje">Selecciona el viaje:</label>
                        <select id="tipo-viaje">
                            <option value="" disabled selected>-- Seleccionar --</option>
                            <option value="Novios">Novios</option>
                            <option value="Senior">Senior</option>
                            <option value="Grupos">Grupos</option>
                            <option value="Combinado">Combinado</option>
                            <option value="Escapadas">Escapadas</option>
                            <option value="Familias con niños">Familias con niños</option>
                        </select>
                    </div>
        
                    <div class="seleccionar">
                        <p>¿Qué servicio necesitas registrar?</p>
                        <div class="radio-group">
                            <label>
                                <input type="radio" name="servicio" value="vuelos" onclick="mostrarSeccion('vuelos')"> Vuelo
                            </label>
                            <label>
                                <input type="radio" name="servicio" value="hospedaje" onclick="mostrarSeccion('hospedaje')"> Alojamiento
                            </label>
                            <label>
                                <input type="radio" name="servicio" value="Otros" onclick="mostrarSeccion('Otros')"> Otros
                            </label>
                        </div>
                        <a href="inicio.php" class="boton">Volver</a>
                    </div>
                </form>
            </div>
        </section>

        <!-- Sección de Hospedaje-->
        <section class="hospedaje" style="display: none;">
            <form method="POST" action="">
                <input type="hidden" name="servicio" value="hospedaje">
                <div class="form-group">
                    <label for="NombreHotel">Nombre del hotel:</label>
                    <input type="text" id="NombreHotel" name="NombreHotel" placeholder="Nombre del hotel">
                </div>
                <div class="form-group">
                    <label for="Ciudad">Ciudad:</label>
                    <input type="text" id="Ciudad" name="Ciudad" placeholder="Ciudad">
                </div>
                <div class="form-group">
                    <label for="Precio">Precio (€):</label>
                    <input type="number" id="Precio" name="Precio" placeholder="Precio (€)">
                </div>
                <div class="form-group">
                    <label for="fecha-entrada">Fecha de entrada:</label>
                    <input type="date" id="fecha-entrada" name="FechaEntrada">
                </div>
                <div class="form-group">
                    <label for="fecha-salida">Fecha de salida:</label>
                    <input type="date" id="fecha-salida" name="FechaSalida">
                </div>
                <div class="form-group">
                    <label for="tipo-habitacion">Tipo de habitación:</label>
                    <select id="tipo-habitacion" name="TipoHab">
                        <option value="" disabled selected>-- Seleccionar --</option>
                        <option value="Individuales">Individuales</option>
                        <option value="Dobles">Dobles</option>
                        <option value="Habitaciones matrimoniale">Habitaciones matrimoniale</option>
                        <option value="Habitaciones familiares">Habitaciones familiares</option>
                        <option value="Habitaciones compartidas">Habitaciones compartidas</option>
                        <option value="Suite">Suite</option>
                        <option value="Junior suite">Junior suite</option>
                        <option value="Gran suite">Gran suite</option>
                        <option value="Suite principal">Suite principal</option>
                    </select>
                </div>
                <button type="submit" name="guardar_servicio" class="btn-submit">Guardar servicio</button>
                <div class="mensaje"></div>
            </form>
        </section>

        <!-- Sección de Vuelos-->
        <section class="vuelos" style="display: none;">
            <form method="POST" action="">
                <input type="hidden" name="servicio" value="vuelos">
                <div class="form-group">
                    <p>Vuelo</p>
                    <p>¿Qué tipo de vuelo es?</p>
                    <div class="radio-group">
                        <label class="opcionVuelo">
                            <input type="radio" name="tipoVuelo" value="Solo ida" onclick="mostrarVuelo('vueloIda')"> Solo ida
                        </label>
                        <label>
                            <input type="radio" name="tipoVuelo" value="Ida y vuelta" onclick="mostrarVuelo('vueloVuelta')"> Ida y vuelta
                        </label>
                    </div>
                </div>
                <section class="vueloIda">
                    <div class="form-group">
                        <label for="AeropuertoOrigen">Aeropuerto de origen:</label>
                        <select id="AeropuertoOrigen" name="AeropuertoOrigen">
                            <option value="" disabled selected>-- Seleccionar --</option>
                            <option value="Alicante">ALC</option>
                            <option value="Asturias">OVD</option>
                            <option value="barcelona">BCN</option>
                            <option value="Ibiza">IBZ</option>
                            <option value="Miami">MIA</option>
                            <option value="LOS ANGELES">LAX</option>
                            <option value="Nueva York">JFK</option>
                            <option value="GRECIA(Atenas)">ATH</option>
                            <option value=" ITALIA (Milán)">MIL</option>
                            <option value="LONDRES (Stanted)">STN</option>
                            <option value=" MARRUECOS (Casablanca) ">CAS</option>
                            <option value="TAILANDIA Bagkok ">BKK</option>
                            <option value="AUSTRALIA (SIYNEY)">SYD</option>
                            <option value="Montreal, Québec">YMQ</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="AeropuertoDestino">Aeropuerto de destino:</label>
                        <select id="AeropuertoDestino" name="AeropuertoDestino">
                            <option value="" disabled selected>-- Seleccionar --</option>
                            <option value="Alicante">ALC</option>
                            <option value="Asturias">OVD</option>
                            <option value="barcelona">BCN</option>
                            <option value="Ibiza">IBZ</option>
                            <option value="Miami">MIA</option>
                            <option value="LOS ANGELES">LAX</option>
                            <option value="Nueva York">JFK</option>
                            <option value="GRECIA(Atenas)">ATH</option>
                            <option value=" ITALIA (Milán)">MIL</option>
                            <option value="LONDRES (Stanted)">STN</option>
                            <option value=" MARRUECOS (Casablanca) ">CAS</option>
                            <option value="TAILANDIA Bagkok ">BKK</option>
                            <option value="AUSTRALIA (SIYNEY)">SYD</option>
                            <option value="Montreal, Québec">YMQ</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="ID_VueloIda">Código-vuelo:</label>
                        <input type="text" id="ID_VueloIda" name="ID_VueloIda" placeholder="Código-vuelo">
                    </div>
                    <div class="form-group">
                        <label for="Aerolinea">Aerolínea:</label>
                        <select id="Aerolinea" name="Aerolinea">
                            <option value="" disabled selected>-- Seleccionar --</option>
                            <option value="JetBlue">JB</option>
                            <option value="Aerolínea Vueling SA">VOY</option>
                            <option value="RYNAIR">RK</option>
                            <option value="Air France ">AC</option>
                            <option value="Croatia Airlines d.d.">OU</option>
                            <option value="British Airways PLC">BA</option>
                            <option value="Virgin Atlantic Airways Ltd">VS</option>
                            <option value="United Airlines Inc">UA</option>
                            <option value="American Airlines">AA</option>
                            <option value="China United Airlines">KN</option>
                            <option value="SWISS Internation Air Lines Ltd">LX</option>
                            <option value="KLM">KL</option>
                            <option value="Air Europa Lineas Aereas, S.A.">UX</option>
                            <option value="Air Greenland">GL</option>
                            <option value="Turkish Airlines Inc">TK</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="Precio">Precio (€):</label>
                        <input type="number" id="Precio" name="Precio" placeholder="Precio (€)">
                    </div>
                    <div class="form-group">
                        <label for="FechaSalida">Fecha de salida:</label>
                        <input type="date" id="FechaSalida" name="FechaSalida">
                    </div>
                    <div class="form-group">
                        <label for="HoraSalida">Hora de salida:</label>
                        <input type="time" id="HoraSalida" name="HoraSalida">
                    </div>
                    <div class="form-group">
                        <label for="Duracion">Duración del vuelo:</label>
                        <input type="text" id="Duracion" name="Duracion" placeholder="Duración del vuelo">
                    </div>
                </section>
                <section class="vueloVuelta" style="display: none;">
                    <div class="form-group">
                        <label for="FechaRegreso">Fecha de regreso:</label>
                        <input type="date" id="FechaRegreso" name="FechaRegreso">
                    </div>
                    <div class="form-group">
                        <label for="HoraRegreso">Hora de regreso:</label>
                        <input type="time" id="HoraRegreso" name="HoraRegreso">
                    </div>
                    <div class="form-group">
                        <label for="DuracionRegreso">Duración del vuelo de regreso:</label>
                        <input type="text" id="DuracionRegreso" name="DuracionRegreso" placeholder="Duración del vuelo regreso">
                    </div>
                    <div class="form-group">
                        <label for="ID_VueloVuelta">Código-vuelo regreso:</label>
                        <input type="text" id="ID_VueloVuelta" name="ID_VueloVuelta" placeholder="Código-vuelo regreso">
                    </div>
                </section>
                <button type="submit" name="guardar_servicio" class="btn-submit">Guardar servicio</button>
                <div class="mensaje"></div>
            </form>
        </section>

        <!-- Sección de Otros Servicios-->
        <section class="Otros" style="display: none;">
            <form method="POST" action="">
                <input type="hidden" name="servicio" value="Otros">
                <div class="form-group">
                    <p>Otros Servicios</p>
                    <label for="Nombre">Nombre</label>
                    <input type="text" id="Nombre" name="Nombre" placeholder="Nombre">
                </div>
                <div class="form-group">
                    <label for="Fecha">Fecha</label>
                    <input type="date" id="Fecha" name="Fecha">
                </div>
                <div class="form-group">
                    <label for="Descripcion">Descripción:</label>
                    <textarea id="Descripcion" name="Descripcion" rows="3" placeholder="Escribe una descripción..."></textarea>
                </div>
                <div class="form-group">
                    <label for="Precio">Precio (€):</label>
                    <input type="number" id="Precio" name="Precio" placeholder="Precio (€)">
                </div>
                <button type="submit" name="guardar_servicio" class="btn-submit">Guardar servicio</button>
                <div class="mensaje"></div>
            </form>
        </section>
    </main>

    <!-- ----------------------Footer------------------------------>
    <footer id="contacto" class="footer">
        <p>📞 Contáctanos: +123 456 789 | ✉️ Email: info@Viajes Erreka-Mari.com</p>
        <p>© 2025 Viajes Erreka-Mari. Todos los derechos reservados.</p>
    </footer>

    
</body>
</html>

    <!-------------------------Script------------------------------>

<script>
    function mostrarSeccion(seccion) {
        document.querySelector('.vuelos').style.display = 'none';
        document.querySelector('.hospedaje').style.display = 'none';
        document.querySelector('.Otros').style.display = 'none';
        document.querySelector('.vueloIda').style.display = 'none';
        document.querySelector('.vueloVuelta').style.display = 'none';
    
        document.querySelector(`.${seccion}`).style.display = 'block';
    }
    
    function mostrarVuelo(tipo) {
        document.querySelector('.vueloIda').style.display = 'block';
            
        if (tipo === 'vueloVuelta') {
            document.querySelector('.vueloVuelta').style.display = 'block';
        } else {
            document.querySelector('.vueloVuelta').style.display = 'none';
        }
    }
</script>


<script>
document.addEventListener("DOMContentLoaded", function () {
    // Validación para vuelos de ida y vuelta
    const fechaIda = document.getElementById("FechaSalida");
    const fechaVuelta = document.getElementById("FechaRegreso");

    if (fechaIda && fechaVuelta) {
        fechaIda.addEventListener("change", validarFechasVuelos);
        fechaVuelta.addEventListener("change", validarFechasVuelos);
    }

    function validarFechasVuelos() {
        if (fechaIda.value && fechaVuelta.value) {
            if (new Date(fechaVuelta.value) < new Date(fechaIda.value)) {
                alert("La fecha de vuelta no puede ser anterior a la fecha de ida.");
                fechaVuelta.value = "";
            }
        }
    }

    // Validación para alojamiento
    const fechaEntrada = document.getElementById("fecha-entrada");
    const fechaSalida = document.getElementById("fecha-salida");

    if (fechaEntrada && fechaSalida) {
        fechaEntrada.addEventListener("change", validarFechasAlojamiento);
        fechaSalida.addEventListener("change", validarFechasAlojamiento);
    }

    function validarFechasAlojamiento() {
        if (fechaEntrada.value && fechaSalida.value) {
            if (new Date(fechaSalida.value) < new Date(fechaEntrada.value)) {
                alert("La fecha de salida no puede ser anterior a la fecha de entrada.");
                fechaSalida.value = ""; 
            }
        }
    }
});
</script>