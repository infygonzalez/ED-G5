<?php
session_start();
include("register.php");

// Verificar si el usuario ha solicitado cerrar sesión
if (isset($_GET['logout']) && $_GET['logout'] === 'true') {
    $_SESSION = array();

    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, 
            $params["path"], 
            $params["domain"], 
            $params["secure"], 
            $params["httponly"]
        );
    }
    session_destroy();
    header("Location: login.php");
    exit();
}

// Obtener el nombre del usuario de la sesión
$nombre_usuario = $_SESSION['nombre'] ?? null; 
$nombre_usuario = mysqli_real_escape_string($conex, $nombre_usuario);

// Obtener el color de marca desde la base de datos
$sql = "SELECT ColorMarca FROM AgenciaViajes WHERE Nombre = '$nombre_usuario'";
$resultado = $conex->query($sql);

$color = "#000000"; 
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    $color = htmlspecialchars($fila['ColorMarca']);
}
$conex->close();
?>

<!-------------------------------------------HTML-------------------------------------------->
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viajes Erreka-Mari</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="img/Logo Reto 2.png">

    <style>
        header, footer {
            background-color: <?php echo $color; ?>;      
          }

    </style>
</head>
<body>


    <!-------------------------------------CABECERA-------------------------------------->
    <header>
        <div class="logo"> <img class="logoimg" src="img/Logo_Reto_2-sinfondo.png"></div>
        <div><h1><?php echo htmlspecialchars($nombre_usuario); ?></h1></div>
        <nav class="menu">
            <ul>
                <li><a href="?logout=true">Cerrar Sesion</a></li>
            </ul>
        </nav>
    </header>

    <!-------------------------------------MAIN------------------------------------------>

    <section class="hero">
        <h1>Descubre tu Próxima Aventura</h1>
        <p>Explora los mejores destinos alrededor del mundo con nosotros.</p>
        <form class="search-form">
            <a href="RegistrarViajes.php">Registrar Viaje</a>
            <a href="FormularioServicios.php">Registrar Servicio</a>
        </form>
    </section>

    <main>
        <div class="search-section">

        <!----------------------------------BUSCADOR----------------------------------->
            <section class="informacion">
                <h3>Registro de Servicios Turísticos:</h3>
                <p>
                    Las empresas pueden registrar sus paquetes turísticos, 
                    vuelos, alojamientos, excursiones y otros servicios de 
                    viaje en la plataforma. 
                </p>
                <h3>Gestión de Reservas:</h3>
                <p>
                    La plataforma incluye herramientas avanzadas de gestión
                    de reservas, donde las empresas pueden rastrear las 
                    solicitudes de clientes, gestionar pagos y confirmar
                    itinerarios en tiempo real.
                </p>

                <h3>Redes sociales</h3>
                <p>
                    Ofrecemos herramientas para gestionar la presencia en redes
                    sociales, permitiendo a las agencias promocionar sus
                    servicios y atraer nuevos clientes a través de contenido 
                    atractivo y relevante. Nos puedes concactar a traves de 
                    la información del pie de página.
                </p>
            </section>

            <section class="extra-info">
                <h3>Simplicidad y Eficiencia:</h3>
                <p>
                    La plataforma está diseñada para ahorrar tiempo, 
                    permitiendo a las empresas concentrarse en ofrecer
                    una experiencia de calidad a sus clientes.
                </p>

                <h3>Flexibilidad:</h3>
                <p>
                    La plataforma es flexible y se adapta a empresas de
                    todos los tamaños, desde pequeñas agencias de viajes
                    locales hasta grandes operadores turísticos internacionales.
                </p>

                <h3>Misión</h3>
                <p>
                    Facilitar la conexión entre agencias de viajes y sus clientes 
                    a través de una plataforma eficiente y accesible, promoviendo 
                    la innovación en la industria del turismo así como dar un producto 
                    fresco con el que las agencias puedan darse a conocer.
                </p>
            </section>
        </div>
        

        <!-------------------------------------PROMOCIONES------------------------------->
        <div class="promo-slider">
            <div class="promo">
                <h2>LOGI Rebajas</h2>
                <img class="fotos" src="./img/LOGI Rebajas.jpg" alt="LOGI Rebajas">
                <p>Precios increíbles para tu Vuelo + Hotel</p>
                <p>Hasta 30% Descuento</p>
            </div>
            <div class="promo">
                <h2>Oferta Caribe</h2>
                <img class="fotos" src="./img/Oferta Caribe.jpg" alt="Oferta Caribe">
                <p>Descubre playas paradisíacas</p>
                <p>Desde 599€</p>
            </div>
            <div class="promo">
                <h2>Escapadas Europeas</h2>
                <img class="fotos" src="./img/Escapadas Europeas.jpg" alt="Escapadas Europeas">
                <p>Praga, Londres, París</p>
                <p>Desde 179€</p>
            </div>
        </div>
    </main>


    <!-------------------------------------FOOTER---------------------------------------->
    <footer id="contacto" class="footer">
        <p>📞 Contáctanos: +123 456 789 | ✉️ Email: info@Viajes Erreka-Mari.com</p>
        <p>© 2025 Viajes Erreka-Mari. Todos los derechos reservados.</p>
    </footer>
</body>
</html>