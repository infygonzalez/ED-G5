<?php
session_start();
include("register.php");

$nombre_usuario = $_SESSION['nombre'] ?? null; 
$nombre_usuario = mysqli_real_escape_string($conex, $nombre_usuario);

$sql = "SELECT ColorMarca FROM AgenciaViajes WHERE Nombre = '$nombre_usuario'";
$resultado = $conex->query($sql);

$color = "#000000"; 
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    $color = htmlspecialchars($fila['ColorMarca']);
}

if ($conex->connect_error) {
    die("Conexión fallida: " . $conex->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Nombre'], $_POST['Tipo'], $_POST['Fecha_Inicio'], $_POST['Fecha_Fin'], $_POST['PaisDestino'], $_POST['Descripcion'], $_POST['ServNoIncluidos'])) {
        
        // Recoger los datos del formulario
        $name = $_POST['Nombre'];
        $tipo_viaje = $_POST['Tipo'];
        $fecha_inicio = $_POST['Fecha_Inicio'];
        $fecha_fin = $_POST['Fecha_Fin'];
        $pais = $_POST['PaisDestino'];
        $descripcion = $_POST['Descripcion'];
        $servicios = $_POST['ServNoIncluidos'];

        // Calcular la duración 
        $Fecha_InicioObj = new DateTime($fecha_inicio);
        $Fecha_FinObj = new DateTime($fecha_fin);
        $intervalo = $Fecha_InicioObj->diff($Fecha_FinObj);
        $dias = $intervalo->days;

       // Obtener el último ID usado
        $sql = "SELECT IdViajes FROM Viajes ORDER BY IdViajes DESC LIMIT 1";
        $result = $conex->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $lastId = $row['IdViajes'];
            $nextIdNumber = (int)$lastId + 1;
            $nextId = str_pad($nextIdNumber, 3, '0', STR_PAD_LEFT);
        } else {
            $nextId = '001'; 
        }

        // Escapar los valores para evitar inyección SQL
        $nextId = $conex->real_escape_string($nextId);
        $name = $conex->real_escape_string($name);
        $tipo_viaje = $conex->real_escape_string($tipo_viaje);
        $fecha_inicio = $conex->real_escape_string($fecha_inicio);
        $fecha_fin = $conex->real_escape_string($fecha_fin);
        $pais = $conex->real_escape_string($pais);
        $descripcion = $conex->real_escape_string($descripcion);
        $servicios = $conex->real_escape_string($servicios);

        // Insertar los datos en la base de datos
        $sql = "INSERT INTO Viajes (IdViajes, Nombre, Tipo, Fecha_Inicio, Fecha_Fin, Duracion_dias, PaisDestino, Descripcion, ServNoIncluidos)
                VALUES ('$nextId', '$name', '$tipo_viaje', '$fecha_inicio', '$fecha_fin', '$dias', '$pais', '$descripcion', '$servicios')";

        if ($conex->query($sql) === TRUE) {
            echo "<script>alert('Nuevo viaje registrado exitosamente con ID: $nextId ');</script>";
        } else {
            $_SESSION['mensaje_error'] = "Error: " . $conex->error;
        }

        // Redirigir solo después de un POST exitoso
        header("Location: registrarViajes.php?exito=1");
        exit();
    } else {
        $_SESSION['mensaje_error'] = "Error: Faltan algunos campos en el formulario.";
        header("Location: registrarViajes.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Para registrar los viajes</title>
    <link rel="stylesheet" href="RegViajes.css">
    <style>
        .mensaje-exito {
            color: green;
            font-weight: bold;
            margin-top: 10px;
        }
        .mensaje-error {
            color: red;
            font-weight: bold;
            margin-top: 10px;
        }
        header, footer {
            background-color: <?php echo $color; ?>;      
          }
    </style>
</head>
<body>
    <header>
        <div class="logo"> <img class="logoimg" src="img/Logo_Reto_2-sinfondo.png"></div>
        <div><h1><?php echo htmlspecialchars($nombre_usuario); ?></h1></div>
        <nav class="menu">
            <ul>
                <li><a>Formulario de Viajes</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <div class="form-container">
            <form class="form" method="POST" action="registrarViajes.php">
                <div class="form-group">
                    <label for="name">Nombre:</label> <br>
                    <input type="text" class="campo" name="Nombre" placeholder="Escribe el nombre del viaje"> 
                </div>
                <br>
                <div class="form-group">
                    <label for="tipo-viaje">Tipo de viaje:</label><br>
                    <select class="campo" name="Tipo">
                        <option value="" disabled selected>-- Seleccionar --</option>
                        <option value="Novios">Novios</option>
                        <option value="Senior">Senior</option>
                        <option value="Grupos">Grupos</option>
                        <option value="Combinado">Combinado</option>
                        <option value="Escapadas">Escapadas</option>
                        <option value="Familias con niños">Familias con niños</option>
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <label for="fecha-inicio">Fecha de inicio:</label><br>
                    <input type="date" class="campo" id="fecha-inicio" name="Fecha_Inicio" onchange="calcularDias()">
                </div>
                <br>
                <div class="form-group">
                    <label for="fecha-fin">Fecha de fin:</label> <br>
                    <input type="date" class="campo" id="fecha-fin" name="Fecha_Fin" onchange="calcularDias()">
                </div>
                <br>
                <div class="form-group">
                    <label for="dias">Días:</label><br>
                    <input type="number" class="campo" id="dias" name="Dias" placeholder="Número de días" readonly>
                </div>
                <br>
                <div class="form-group">
                    <label for="pais">País:</label><br>
                    <select class="campo" name="PaisDestino">
                        <option value="" disabled selected>-- Seleccionar --</option>
                        <option value="ALEMANIA">ALEMANIA</option>
                        <option value="Argentina">Argentina</option>
                        <option value="AUSTRIA">AUSTRIA</option>
                        <option value="BÉLGICA">BÉLGICA</option>
                        <option value="BRASIL">BRASIL</option>
                        <option value="CANADA">CANADA</option>
                        <option value="CROACIA">CROACIA</option>
                        <option value="REPUBLICA CHECA">REPUBLICA CHECA</option>
                        <option value="CUBA">CUBA</option>
                        <option value="CHINA">CHINA</option>
                        <option value="CHIPRE">CHIPRE</option>
                        <option value="DINAMARCA">DINAMARCA</option>
                        <option value="EGIPTO">EGIPTO</option>
                        <option value="ESPAÑA">ESPAÑA</option>
                        <option value="ESTADOS UNIDOS">ESTADOS UNIDOS</option>
                        <option value="ESTONIA">ESTONIA</option>
                        <option value="FINLANDIA">FINLANDIA</option>
                        <option value="FRANCIA">FRANCIA</option>
                        <option value="GRECIA">GRECIA</option>
                        <option value="GUATEMALA">GUATEMALA</option>
                        <option value="HONG-KONG">HONG-KONG</option>
                        <option value="HUNGRIA">HUNGRIA</option>
                        <option value="INDIA">INDIA</option>
                        <option value="INDONESIA">INDONESIA</option>
                        <option value="IRLANDA">IRLANDA</option>
                        <option value="ISLANDIA">ISLANDIA</option>
                        <option value="ISRAEL">ISRAEL</option>
                        <option value="ITALIA">ITALIA</option>
                        <option value="jAMAICA">jAMAICA</option>
                        <option value="JAPÓN">JAPÓN</option>
                        <option value="KENIA">KENIA</option>
                        <option value="LUXEMBURGO">LUXEMBURGO</option>
                        <option value="MALDIVAS">MALDIVAS</option>
                        <option value="MALTA">MALTA</option>
                        <option value="MARRUECOS">MARRUECOS</option>
                        <option value="MEXICO">MEXICO</option>
                        <option value="MÓNACO">MÓNACO</option>
                        <option value="NORUEGA">NORUEGA</option>
                        <option value="PAISES BAJOS">PAISES BAJOS</option>
                        <option value="PANAMÁ">PANAMÁ</option>
                        <option value="PERÚ">PERÚ</option>
                        <option value="POLONIA">POLONIA</option>
                        <option value="PORTUGAL">PORTUGAL</option>
                        <option value="PUERTO RICO">PUERTO RICO</option>
                        <option value="QATAR">QATAR</option>
                        <option value="REINO UNIDO">REINO UNIDO</option>
                        <option value="RUMANIA">RUMANIA</option>
                        <option value="RUSIA">RUSIA</option>
                        <option value="SEYCHELLES">SEYCHELLES</option>
                        <option value="SINGAPUR">SINGAPUR</option>
                        <option value="SUDÁFRICA">SUDÁFRICA</option>
                        <option value="SUECIA">SUECIA</option>
                        <option value="SUIZA">SUIZA</option>
                        <option value="TAILANDIA">TAILANDIA</option>
                        <option value="TANZANIA (INCLUYE ZANZIBAR)">TANZANIA (INCLUYE ZANZIBAR)</option>
                        <option value="TÚNEZ">TÚNEZ</option>
                        <option value="TURQUIA">TURQUIA</option>
                        <option value="VENEZUELA">VENEZUELA</option>
                        <option value="VIETNAM">VIETNAM</option>
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <label for="descripcion">Descripción:</label><br>
                    <textarea id="descripcion" name="Descripcion" rows="3" placeholder="Escribe una descripción..."></textarea>
                </div>
                <br>
                <div class="form-group">
                    <label for="servicios">Servicios excluidos:</label><br>
                    <textarea id="servicios" name="ServNoIncluidos" rows="3" placeholder="Indica los servicios excluidos..."></textarea>
                </div>

                <div class="button-container">
                    <button type="submit" class="boton">GUARDAR</button>
                    <a href="inicio.php" class="boton">VOLVER</a>

                    <?php if (isset($_GET['exito'])): ?>
                    <script>alert('Viaje agregado exitosamente')</script>
                    <?php endif; ?>
                </div>

            </form>
        </div> 
    </main>
    
    <footer id="contacto" class="footer">
        <p>📞 Contáctanos: +123 456 789 | ✉️ Email: info@Viajes Erreka-Mari.com</p>
        <p>© 2025 Viajes Erreka-Mari. Todos los derechos reservados.</p>
    </footer>
</body>
</html>

<script>
    function calcularDias() {
        const Fecha_Inicio = document.getElementById('fecha-inicio').value;
        const Fecha_Fin = document.getElementById('fecha-fin').value;

         if (Fecha_Inicio && Fecha_Fin) {
            const inicio = new Date(Fecha_Inicio);
             const fin = new Date(Fecha_Fin);
            const diferencia = fin - inicio;
            const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
            document.getElementById('dias').value = dias;
         }
    }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    // Validación de inicio y fin
    const fechaIda = document.getElementById("fecha-inicio");
    const fechaVuelta = document.getElementById("fecha-fin");

    if (fechaIda && fechaVuelta) {
        fechaIda.addEventListener("change", validarFechasVuelos);
        fechaVuelta.addEventListener("change", validarFechasVuelos);
    }

    function validarFechasVuelos() {
        if (fechaIda.value && fechaVuelta.value) {
            if (new Date(fechaVuelta.value) < new Date(fechaIda.value)) {
                alert("La fecha de vuelta no puede ser anterior a la fecha de ida.");
                fechaVuelta.value = "";
            }
        }
    }
});
</script>