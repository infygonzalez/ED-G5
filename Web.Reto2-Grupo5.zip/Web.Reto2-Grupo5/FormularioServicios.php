<?php
session_start();
include("register.php");

$nombre_usuario = $_SESSION['nombre'] ?? null; 
$nombre_usuario = mysqli_real_escape_string($conex, $nombre_usuario);

// Verificar conexión
if (!isset($conex) || $conex->connect_error) {
    die("Conexión fallida: " . $conex->connect_error);
}

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_servicio'])) {
    if (isset($_POST['servicio'])) {
        $tipo_servicio = $_POST['servicio'];

        switch ($tipo_servicio) {
            case 'vuelos':
                $mensaje = procesarVuelo($conex);
                break;
            case 'hospedaje':
                $mensaje = procesarAlojamiento($conex);
                break;
            case 'Otros':
                $mensaje = procesarOtros($conex);
                break;
            default:
                $mensaje = "Error: Tipo de servicio no válido.";
        }
    } else {
        $mensaje = "Error: No se ha especificado el tipo de servicio.";
    }
}

// Función para procesar los datos de vuelos--------------------------------------------------------------------------------------------------------------------
function procesarVuelo($conex) {
    // Validar campos obligatorios para el vuelo de ida
    $required_fields_ida = ['AeropuertoOrigen', 'AeropuertoDestino', 'ID_VueloIda', 'Aerolinea', 'Precio', 'FechaSalida', 'HoraSalida', 'Duracion'];
    foreach ($required_fields_ida as $field) {
        if (empty($_POST[$field])) {
            $error_msg = "Error: El campo $field es obligatorio para vuelos de ida.";
            echo "<script>alert('$error_msg');</script>";
            return;
        }
    }

    // Datos del vuelo de ida
    $AeropuertoOrigen = trim($_POST['AeropuertoOrigen']);
    $AeropuertoDestino = trim($_POST['AeropuertoDestino']);
    $ID_VueloIda = trim($_POST['ID_VueloIda']);
    $Aerolinea = trim($_POST['Aerolinea']);
    $Precio = trim($_POST['Precio']);
    $FechaSalida = trim($_POST['FechaSalida']);
    $HoraSalida = trim($_POST['HoraSalida']);
    $Duracion = trim($_POST['Duracion']);

    // Verificar si el código de vuelo ya existe
    $consulta = "SELECT COUNT(*) as total FROM VueloIda WHERE ID_VueloIda = '$ID_VueloIda'";
    $resultado = mysqli_query($conex, $consulta);
    if ($resultado && $resultado->fetch_assoc()['total'] > 0) {
        echo "<script>alert('Error: El código de vuelo ya existe.');</script>";
        return;
    }

    // Verificar si la aerolínea existe antes de insertar
    $check_sql = "SELECT ID_aerolinea FROM aerolinea WHERE ID_aerolinea = ?";
    $stmt_check = $conex->prepare($check_sql);
    $stmt_check->bind_param("s", $Aerolinea);
    $stmt_check->execute();
    $stmt_check->store_result();
    if ($stmt_check->num_rows == 0) {
        echo "<script>alert('Error: La aerolínea especificada no existe.');</script>";
        return;
    }
    $stmt_check->close();

    // Insertar vuelo de ida
    $sql = "INSERT INTO VueloIda (ID_VueloIda, IdViajes, AeropuertoOrigen, AeropuertoDestino, Precio, Aerolinea, FechaSalida, HoraSalida, Duracion) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conex->prepare($sql);
    if (!$stmt) {
        echo "<script>alert('Error en la preparación de la consulta: {$conex->error}');</script>";
        return;
    }
    $IdViajes = '1';
    $stmt->bind_param("ssssdssss", $ID_VueloIda, $IdViajes, $AeropuertoOrigen, $AeropuertoDestino, $Precio, $Aerolinea, $FechaSalida, $HoraSalida, $Duracion);
    if ($stmt->execute()) {
        echo "<script>alert('Vuelo de ida agregado exitosamente.');</script>";
    } else {
        echo "<script>alert('Error en la ejecución de la consulta: {$stmt->error}');</script>";
    }
    $stmt->close();

    // Procesar vuelo de vuelta si se seleccionó "Ida y vuelta"
    if (isset($_POST['tipoVuelo']) && $_POST['tipoVuelo'] === 'Ida y vuelta') {
        // Validar campos obligatorios para el vuelo de vuelta
        $required_fields_vuelta = ['ID_VueloVuelta', 'FechaSalida', 'HoraSalida', 'Duracion', 'Aerolinea'];
        foreach ($required_fields_vuelta as $field) {
            if (empty($_POST[$field])) {
                $error_msg = "Error: El campo $field es obligatorio para vuelos de vuelta.";
                echo "<script>alert('$error_msg');</script>";
                return;
            }
        }

        // Datos del vuelo de vuelta
        $ID_VueloVuelta = trim($_POST['ID_VueloVuelta']);
        $FechaRegreso = trim($_POST['FechaRegreso']);
        $HoraRegreso = trim($_POST['HoraRegreso']);
        $DuracionRegreso = trim($_POST['DuracionRegreso']);
        $AerolineaRegreso = trim($_POST['Aerolinea']);

        // Obtener datos del vuelo de ida para el vuelo de vuelta
        $sqlIda = "SELECT AeropuertoOrigen, AeropuertoDestino, Precio FROM VueloIda WHERE ID_VueloIda = ?";
        $stmtIda = $conex->prepare($sqlIda);
        $stmtIda->bind_param("s", $ID_VueloIda);
        $stmtIda->execute();
        $resultadoIda = $stmtIda->get_result();
        if ($filaIda = $resultadoIda->fetch_assoc()) {
            $AeropuertoOrigenVuelta = $filaIda['AeropuertoDestino'];
            $AeropuertoDestinoVuelta = $filaIda['AeropuertoOrigen'];
            $PrecioVuelta = $filaIda['Precio'];
        } else {
            echo "<script>alert('Error: No se encontró un vuelo de ida para este viaje.');</script>";
            return;
        }
        $stmtIda->close();

      // Insertar vuelo de vuelta
        $sqlVuelta = "INSERT INTO VueloVuelta (ID_VueloVuelta, ID_VueloIda, IdViajes, AeropuertoOrigen, AeropuertoDestino, Precio, Aerolinea, FechaSalida, HoraSalida, Duracion) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmtVuelta = $conex->prepare($sqlVuelta);
        if (!$stmtVuelta) {
        echo "<script>alert('Error en la preparación de la consulta: {$conex->error}');</script>";
        return;
        }

        $stmtVuelta->bind_param("sssssdssss", $ID_VueloVuelta, $ID_VueloIda, $IdViajes, $AeropuertoOrigenVuelta, $AeropuertoDestinoVuelta, $PrecioVuelta, $AerolineaRegreso, $FechaRegreso, $HoraRegreso, $DuracionRegreso);

        if ($stmtVuelta->execute()) {
        echo "<script>alert('Vuelo de vuelta agregado exitosamente.');</script>";
        } else {
        echo "<script>alert('Error en la ejecución de la consulta: {$stmtVuelta->error}');</script>";
        }
        $stmtVuelta->close();
    }
}

// Función para procesar los datos de alojamiento-------------------------------------------------------------------------------------------------------------------
function procesarAlojamiento($conex) {
    // Validar campos obligatorios
    $required_fields = ['NombreHotel', 'Ciudad', 'Precio', 'FechaEntrada', 'FechaSalida', 'TipoHab'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $error_msg = "Error: El campo $field es obligatorio para alojamiento.";
            echo "<script>alert('$error_msg');</script>";
            return;
        }
    }

    $NombreHotel = trim($_POST['NombreHotel']);
    $Ciudad = trim($_POST['Ciudad']);
    $Precio = trim($_POST['Precio']);
    $FechaEntrada = trim($_POST['FechaEntrada']);
    $FechaSalida = trim($_POST['FechaSalida']);
    $TipoHab = trim($_POST['TipoHab']);

    // Obtener el último ID de eventos
    $consulta = "SELECT MAX(IdEventos) as max_id FROM Eventos";
    $resultado = mysqli_query($conex, $consulta);
    $row = mysqli_fetch_assoc($resultado);
    $IdEventos = $row['max_id'] ? $row['max_id'] + 1 : 1;

    // Insertar el nuevo evento
    $sqlEvento = "INSERT INTO Eventos (IdEventos, Nombre, Tipo, Precio, Fecha, Descripcion, IdViajes) 
                  VALUES (?, ?, 'Alojamiento', ?, ?, '', ?)";
    
    $stmtEvento = $conex->prepare($sqlEvento);
    if (!$stmtEvento) {
        $error_msg = "Error en la preparación de la consulta de eventos: " . $conex->error;
        echo "<script>alert('$error_msg');</script>";
        return;
    }

    $IdViajes = '1';
    $stmtEvento->bind_param("sssss", $IdEventos, $NombreHotel, $Precio, $FechaEntrada, $IdViajes);
    
    if (!$stmtEvento->execute()) {
        $stmtEvento->close();
        $error_msg = "Error en la ejecución de la consulta de eventos: " . $stmtEvento->error;
        echo "<script>alert('$error_msg');</script>";
        return;
    }
    $stmtEvento->close();

    // Ahora insertar el alojamiento
    $sqlAlojamiento = "INSERT INTO Alojamiento (IdAlojamiento, NombreHotel, Ciudad, Precio, FechaEntrada, FechaSalida, TipoHab, IdEventos) 
                       VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?)";
    
    $stmtAlojamiento = $conex->prepare($sqlAlojamiento);
    if (!$stmtAlojamiento) {
        $error_msg = "Error en la preparación de la consulta de alojamiento: " . $conex->error;
        echo "<script>alert('$error_msg');</script>";
        return;
    }
    
    $stmtAlojamiento->bind_param("ssdssss", $NombreHotel, $Ciudad, $Precio, $FechaEntrada, $FechaSalida, $TipoHab, $IdEventos);
    
    if ($stmtAlojamiento->execute()) {
        $stmtAlojamiento->close();
        $exito_msg = "Nuevo alojamiento agregado exitosamente.";
        echo "<script>alert('$exito_msg');</script>";
    } else {
        $stmtAlojamiento->close();
        $error_msg = "Error en la ejecución de la consulta de alojamiento: " . $stmtAlojamiento->error;
        echo "<script>alert('$error_msg');</script>";
    }
}
// Función para procesar los datos de otros servicios----------------------------------------------------------------------------------------------------------------
 function procesarOtros($conex) {
    $required_fields = ['Nombre', 'Fecha', 'Descripcion', 'Precio'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $error_msg = "Error: El campo $field es obligatorio para otros servicios.";
            echo "<script>alert('$error_msg');</script>";
            return;
        }
    }

    $Nombre = trim($_POST['Nombre']);
    $Fecha = trim($_POST['Fecha']);
    $Descripcion = trim($_POST['Descripcion']);
    $Precio = trim($_POST['Precio']);

    // Obtener el último ID de viajes
    $consulta = "SELECT MAX(IdViajes) as max_id FROM Viajes";
    $resultado = mysqli_query($conex, $consulta);
    $row = mysqli_fetch_assoc($resultado);
    $IdViajes = $row['max_id'] ? $row['max_id'] : 1; 

    // Obtener el último ID de eventos
    $consulta = "SELECT MAX(IdEventos) as max_id FROM Eventos";
    $resultado = mysqli_query($conex, $consulta);
    $row = mysqli_fetch_assoc($resultado);
    $IdEventos = $row['max_id'] ? $row['max_id'] + 1 : 1;

    // Insertar otros servicios
    $sql = "INSERT INTO Eventos (IdEventos, Nombre, Tipo, Precio, Fecha, Descripcion, IdViajes) 
            VALUES (UUID(), ?, 'Otros', ?, ?, ?, ?)";
    
    $stmt = $conex->prepare($sql);
    if (!$stmt) {
        $error_msg = "Error en la preparación de la consulta: " . $conex->error;
        echo "<script>alert('$error_msg');</script>";
        return;
    }

    // Se cambia el orden de los parámetros en bind_param
    $stmt->bind_param("sssss", $Nombre, $Precio, $Fecha, $Descripcion, $IdViajes);
    
    if ($stmt->execute()) {
        $stmt->close();
        $exito_msg = "Nuevo servicio agregado exitosamente.";
        echo "<script>alert('$exito_msg');</script>";
    } else {
        $stmt->close();
        $error_msg = "Error en la ejecución de la consulta: " . $stmt->error;
        echo "<script>alert('$error_msg');</script>";
    }
}
?>


<!-------------------------------HTML-------------------------------->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Servicios</title>
    <link rel="stylesheet" href="Servicios.css">
    <style>
        /* Estilos para los mensajes */
        .mensaje {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .mensaje-exito {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .mensaje-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <!-- ----------------------Header------------------------------>
    <header>
        <div class="logo"> <img class="logoimg" src="img/Logo_Reto_2-sinfondo.png"></div>
        <div><h1><?php echo htmlspecialchars($nombre_usuario); ?></h1></div>
        <nav class="menu">
            <ul>
                <li><a>Formulario de Servicios</a></li>
            </ul>
        </nav>
    </header>

    <!-- ----------------------Main------------------------------>
    <main>
        <!-- Sección principal-->
        <section>
            <div class="form-container">
                <form class="form">
                    <div class="form-group">
                        <label for="tipo-viaje">Selecciona el viaje:</label>
                        <select id="tipo-viaje">
                            <option value="" disabled selected>-- Seleccionar --</option>
                            <option value="Novios">Novios</option>
                            <option value="Senior">Senior</option>
                            <option value="Grupos">Grupos</option>
                            <option value="Combinado">Combinado</option>
                            <option value="Escapadas">Escapadas</option>
                            <option value="Familias con niños">Familias con niños</option>
                        </select>
                    </div>
        
                    <div class="seleccionar">
                        <p>¿Qué servicio necesitas registrar?</p>
                        <div class="radio-group">
                            <label>
                                <input type="radio" name="servicio" value="vuelos" onclick="mostrarSeccion('vuelos')"> Vuelo
                            </label>
                            <label>
                                <input type="radio" name="servicio" value="hospedaje" onclick="mostrarSeccion('hospedaje')"> Alojamiento
                            </label>
                            <label>
                                <input type="radio" name="servicio" value="Otros" onclick="mostrarSeccion('Otros')"> Otros
                            </label>
                        </div>
                        <a href="inicio.php" class="boton">Volver</a>
                    </div>
                </form>
            </div>
        </section>

        <!-- Sección de Hospedaje-->
        <section class="hospedaje" style="display: none;">
            <form method="POST" action="">
                <input type="hidden" name="servicio" value="hospedaje">
                <div class="form-group">
                    <label for="NombreHotel">Nombre del hotel:</label>
                    <input type="text" id="NombreHotel" name="NombreHotel" placeholder="Nombre del hotel">
                </div>
                <div class="form-group">
                    <label for="Ciudad">Ciudad:</label>
                    <input type="text" id="Ciudad" name="Ciudad" placeholder="Ciudad">
                </div>
                <div class="form-group">
                    <label for="Precio">Precio (€):</label>
                    <input type="number" id="Precio" name="Precio" placeholder="Precio (€)">
                </div>
                <div class="form-group">
                    <label for="fecha-entrada">Fecha de entrada:</label>
                    <input type="date" id="fecha-entrada" name="FechaEntrada">
                </div>
                <div class="form-group">
                    <label for="fecha-salida">Fecha de salida:</label>
                    <input type="date" id="fecha-salida" name="FechaSalida">
                </div>
                <div class="form-group">
                    <label for="tipo-habitacion">Tipo de habitación:</label>
                    <select id="tipo-habitacion" name="TipoHab">
                        <option value="" disabled selected>-- Seleccionar --</option>
                        <option value="Individuales">Individuales</option>
                        <option value="Dobles">Dobles</option>
                        <option value="Habitaciones matrimoniale">Habitaciones matrimoniale</option>
                        <option value="Habitaciones familiares">Habitaciones familiares</option>
                        <option value="Habitaciones compartidas">Habitaciones compartidas</option>
                        <option value="Suite">Suite</option>
                        <option value="Junior suite">Junior suite</option>
                        <option value="Gran suite">Gran suite</option>
                        <option value="Suite principal">Suite principal</option>
                    </select>
                </div>
                <button type="submit" name="guardar_servicio" class="btn-submit">Guardar servicio</button>
                <div class="mensaje"></div>
            </form>
        </section>

        <!-- Sección de Vuelos-->
        <section class="vuelos" style="display: none;">
            <form method="POST" action="">
                <input type="hidden" name="servicio" value="vuelos">
                <div class="form-group">
                    <p>Vuelo</p>
                    <p>¿Qué tipo de vuelo es?</p>
                    <div class="radio-group">
                        <label class="opcionVuelo">
                            <input type="radio" name="tipoVuelo" value="Solo ida" onclick="mostrarVuelo('vueloIda')"> Solo ida
                        </label>
                        <label>
                            <input type="radio" name="tipoVuelo" value="Ida y vuelta" onclick="mostrarVuelo('vueloVuelta')"> Ida y vuelta
                        </label>
                    </div>
                </div>
                <section class="vueloIda">
                    <div class="form-group">
                        <label for="AeropuertoOrigen">Aeropuerto de origen:</label>
                        <select id="AeropuertoOrigen" name="AeropuertoOrigen">
                            <option value="" disabled selected>-- Seleccionar --</option>
                            <option value="Alicante">ALC</option>
                            <option value="Asturias">OVD</option>
                            <option value="barcelona">BCN</option>
                            <option value="Ibiza">IBZ</option>
                            <option value="Miami">MIA</option>
                            <option value="LOS ANGELES">LAX</option>
                            <option value="Nueva York">JFK</option>
                            <option value="GRECIA(Atenas)">ATH</option>
                            <option value=" ITALIA (Milán)">MIL</option>
                            <option value="LONDRES (Stanted)">STN</option>
                            <option value=" MARRUECOS (Casablanca) ">CAS</option>
                            <option value="TAILANDIA Bagkok ">BKK</option>
                            <option value="AUSTRALIA (SIYNEY)">SYD</option>
                            <option value="Montreal, Québec">YMQ</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="AeropuertoDestino">Aeropuerto de destino:</label>
                        <select id="AeropuertoDestino" name="AeropuertoDestino">
                            <option value="" disabled selected>-- Seleccionar --</option>
                            <option value="Alicante">ALC</option>
                            <option value="Asturias">OVD</option>
                            <option value="barcelona">BCN</option>
                            <option value="Ibiza">IBZ</option>
                            <option value="Miami">MIA</option>
                            <option value="LOS ANGELES">LAX</option>
                            <option value="Nueva York">JFK</option>
                            <option value="GRECIA(Atenas)">ATH</option>
                            <option value=" ITALIA (Milán)">MIL</option>
                            <option value="LONDRES (Stanted)">STN</option>
                            <option value=" MARRUECOS (Casablanca) ">CAS</option>
                            <option value="TAILANDIA Bagkok ">BKK</option>
                            <option value="AUSTRALIA (SIYNEY)">SYD</option>
                            <option value="Montreal, Québec">YMQ</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="ID_VueloIda">Código-vuelo:</label>
                        <input type="text" id="ID_VueloIda" name="ID_VueloIda" placeholder="Código-vuelo">
                    </div>
                    <div class="form-group">
                        <label for="Aerolinea">Aerolínea:</label>
                        <select id="Aerolinea" name="Aerolinea">
                            <option value="1">Vueling</option>
                            <option value="2">SARYANAIR</option>
                            <option value="3">World2Fly</option>
                            <option value="4">Air France</option>
                            <option value="5">KLM</option>
                            <option value="6">KLM Cityhopper</option>
                            <option value="7">TAP Portugal</option>
                            <option value="8">World 2 Fly Portugal, S.A.</option>
                            <option value="9">Finnair</option>
                            <option value="10">Brussels Airlines</option>
                            <option value="11">Condor Flugdienst GmbH</option>
                            <option value="12">Lufthansa</option>
                            <option value="13">Lufthansa CityLine GmbH</option>
                            <option value="14">TUIfly GmbH</option>
                            <option value="15">TUIfly Nordic AB</option>
                            <option value="16">Croatia Airlines d.d.</option>
                            <option value="17">Air Nostrum, Lineas aereas del Mediterraneo SA</option>
                            <option value="18">SATA (Air Acores)</option>
                            <option value="19">SATA Internacional - Azores Airlines, S.A.</option>
                            <option value="20">Air Europa Lineas Aereas, S.A.</option>
                            <option value="21">British Airways PLC</option>
                            <option value="22">BA Euroflyer Limited dba British Airways</option>
                            <option value="23">Virgin Atlantic Airways Ltd</option>
                            <option value="24">Norse Atlantic Airways AS</option>
                            <option value="25">Challenge Airlines (BE) S.A.</option>
                            <option value="26">EASYJET UK LIMITED</option>
                            <option value="27">Easyjet Switzerland S.A</option>
                            <option value="28">Edelweiss Air AG</option>
                            <option value="29">Air Greenland</option>
                            <option value="30">SWISS International Air Lines Ltd</option>
                            <option value="31">Turkish Airlines Inc</option>
                            <option value="32">Pegasus Airlines</option>
                            <option value="33">Malta Air Travel Ltd dba Malta MedAir</option>
                            <option value="34">Alitalia</option>
                            <option value="35">American Airlines</option>
                            <option value="36">BSA - Aerolinhas Brasileiras S.A dba LATAM Cargo Br</option>
                            <option value="37">Tam Linhas Aereas SA dba Latam Airlines Brasil</option>
                            <option value="38">Delta Air Lines Inc</option>
                            <option value="39">United Airlines Inc</option>
                            <option value="40">China United Airlines</option>
                            <option value="41">AVIANCA-Ecuador dba AVIANCA</option>
                            <option value="42">Aerovias del Continente Americano S.A. AVIANCA</option>
                            <option value="43">Egyptair</option>
                            <option value="44">Aerovias de Mexico SA de CV dba AeroMexico</option>
                            <option value="45">Aerolineas Argentinas S.A.</option>
                            <option value="46">Air Transat</option>
                            <option value="47">Alia - The Royal Jordanian Airlines dba Royal Jordanian</option>
                            <option value="48">Qatar Airways Group Q.C.S.C dba Qatar Airways</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="Precio">Precio (€):</label>
                        <input type="number" id="Precio" name="Precio" placeholder="Precio (€)">
                    </div>
                    <div class="form-group">
                        <label for="FechaSalida">Fecha de salida:</label>
                        <input type="date" id="FechaSalida" name="FechaSalida">
                    </div>
                    <div class="form-group">
                        <label for="HoraSalida">Hora de salida:</label>
                        <input type="time" id="HoraSalida" name="HoraSalida">
                    </div>
                    <div class="form-group">
                        <label for="Duracion">Duración del vuelo:</label>
                        <input type="text" id="Duracion" name="Duracion" placeholder="Duración del vuelo">
                    </div>
                </section>
                <section class="vueloVuelta" style="display: none;">
                    <div class="form-group">
                        <label for="FechaRegreso">Fecha de regreso:</label>
                        <input type="date" id="FechaRegreso" name="FechaRegreso">
                    </div>
                    <div class="form-group">
                        <label for="HoraRegreso">Hora de regreso:</label>
                        <input type="time" id="HoraRegreso" name="HoraRegreso">
                    </div>
                    <div class="form-group">
                        <label for="DuracionRegreso">Duración del vuelo de regreso:</label>
                        <input type="text" id="DuracionRegreso" name="DuracionRegreso" placeholder="Duración del vuelo regreso">
                    </div>
                    <div class="form-group">
                        <label for="ID_VueloVuelta">Código-vuelo regreso:</label>
                        <input type="text" id="ID_VueloVuelta" name="ID_VueloVuelta" placeholder="Código-vuelo regreso">
                    </div>
                    <label for="AerolineaRegreso">Aerolínea de regreso:</label>
                        <select id="Aerolinea" name="Aerolinea">
                            <option value="1">Vueling</option>
                            <option value="2">SARYANAIR</option>
                            <option value="3">World2Fly</option>
                            <option value="4">Air France</option>
                            <option value="5">KLM</option>
                            <option value="6">KLM Cityhopper</option>
                            <option value="7">TAP Portugal</option>
                            <option value="8">World 2 Fly Portugal, S.A.</option>
                            <option value="9">Finnair</option>
                            <option value="10">Brussels Airlines</option>
                            <option value="11">Condor Flugdienst GmbH</option>
                            <option value="12">Lufthansa</option>
                            <option value="13">Lufthansa CityLine GmbH</option>
                            <option value="14">TUIfly GmbH</option>
                            <option value="15">TUIfly Nordic AB</option>
                            <option value="16">Croatia Airlines d.d.</option>
                            <option value="17">Air Nostrum, Lineas aereas del Mediterraneo SA</option>
                            <option value="18">SATA (Air Acores)</option>
                            <option value="19">SATA Internacional - Azores Airlines, S.A.</option>
                            <option value="20">Air Europa Lineas Aereas, S.A.</option>
                            <option value="21">British Airways PLC</option>
                            <option value="22">BA Euroflyer Limited dba British Airways</option>
                            <option value="23">Virgin Atlantic Airways Ltd</option>
                            <option value="24">Norse Atlantic Airways AS</option>
                            <option value="25">Challenge Airlines (BE) S.A.</option>
                            <option value="26">EASYJET UK LIMITED</option>
                            <option value="27">Easyjet Switzerland S.A</option>
                            <option value="28">Edelweiss Air AG</option>
                            <option value="29">Air Greenland</option>
                            <option value="30">SWISS International Air Lines Ltd</option>
                            <option value="31">Turkish Airlines Inc</option>
                            <option value="32">Pegasus Airlines</option>
                            <option value="33">Malta Air Travel Ltd dba Malta MedAir</option>
                            <option value="34">Alitalia</option>
                            <option value="35">American Airlines</option>
                            <option value="36">BSA - Aerolinhas Brasileiras S.A dba LATAM Cargo Br</option>
                            <option value="37">Tam Linhas Aereas SA dba Latam Airlines Brasil</option>
                            <option value="38">Delta Air Lines Inc</option>
                            <option value="39">United Airlines Inc</option>
                            <option value="40">China United Airlines</option>
                            <option value="41">AVIANCA-Ecuador dba AVIANCA</option>
                            <option value="42">Aerovias del Continente Americano S.A. AVIANCA</option>
                            <option value="43">Egyptair</option>
                            <option value="44">Aerovias de Mexico SA de CV dba AeroMexico</option>
                            <option value="45">Aerolineas Argentinas S.A.</option>
                            <option value="46">Air Transat</option>
                            <option value="47">Alia - The Royal Jordanian Airlines dba Royal Jordanian</option>
                            <option value="48">Qatar Airways Group Q.C.S.C dba Qatar Airways</option>
                        </select>
                </section>
                <button type="submit" name="guardar_servicio" class="btn-submit">Guardar servicio</button>
                <div class="mensaje"></div>
            </form>
        </section>

        <!-- Sección de Otros Servicios-->
        <section class="Otros" style="display: none;">
            <form method="POST" action="">
                <input type="hidden" name="servicio" value="Otros">
                <div class="form-group">
                    <p>Otros Servicios</p>
                    <label for="Nombre">Nombre</label>
                    <input type="text" id="Nombre" name="Nombre" placeholder="Nombre">
                </div>
                <div class="form-group">
                    <label for="Fecha">Fecha</label>
                    <input type="date" id="Fecha" name="Fecha">
                </div>
                <div class="form-group">
                    <label for="Descripcion">Descripción:</label>
                    <textarea id="Descripcion" name="Descripcion" rows="3" placeholder="Escribe una descripción..."></textarea>
                </div>
                <div class="form-group">
                    <label for="Precio">Precio (€):</label>
                    <input type="number" id="Precio" name="Precio" placeholder="Precio (€)">
                </div>
                <button type="submit" name="guardar_servicio" class="btn-submit">Guardar servicio</button>
                <div class="mensaje"></div>
            </form>
        </section>
    </main>

    <!-- ----------------------Footer------------------------------>
    <footer id="contacto" class="footer">
        <p>📞 Contáctanos: +123 456 789 | ✉️ Email: info@Viajes Erreka-Mari.com</p>
        <p>© 2025 Viajes Erreka-Mari. Todos los derechos reservados.</p>
    </footer>

    
</body>
</html>

    <!-------------------------Script------------------------------>

<script>
    function mostrarSeccion(seccion) {
        document.querySelector('.vuelos').style.display = 'none';
        document.querySelector('.hospedaje').style.display = 'none';
        document.querySelector('.Otros').style.display = 'none';
        document.querySelector('.vueloIda').style.display = 'none';
        document.querySelector('.vueloVuelta').style.display = 'none';
    
        document.querySelector(`.${seccion}`).style.display = 'block';
    }
    
    function mostrarVuelo(tipo) {
        document.querySelector('.vueloIda').style.display = 'block';
            
        if (tipo === 'vueloVuelta') {
            document.querySelector('.vueloVuelta').style.display = 'block';
        } else {
            document.querySelector('.vueloVuelta').style.display = 'none';
        }
    }
</script>


<script>
document.addEventListener("DOMContentLoaded", function () {
    // Validación para vuelos de ida y vuelta
    const fechaIda = document.getElementById("FechaSalida");
    const fechaVuelta = document.getElementById("FechaRegreso");

    if (fechaIda && fechaVuelta) {
        fechaIda.addEventListener("change", validarFechasVuelos);
        fechaVuelta.addEventListener("change", validarFechasVuelos);
    }

    function validarFechasVuelos() {
        if (fechaIda.value && fechaVuelta.value) {
            if (new Date(fechaVuelta.value) < new Date(fechaIda.value)) {
                alert("La fecha de vuelta no puede ser anterior a la fecha de ida.");
                fechaVuelta.value = "";
            }
        }
    }

    // Validación para alojamiento
    const fechaEntrada = document.getElementById("fecha-entrada");
    const fechaSalida = document.getElementById("fecha-salida");

    if (fechaEntrada && fechaSalida) {
        fechaEntrada.addEventListener("change", validarFechasAlojamiento);
        fechaSalida.addEventListener("change", validarFechasAlojamiento);
    }

    function validarFechasAlojamiento() {
        if (fechaEntrada.value && fechaSalida.value) {
            if (new Date(fechaSalida.value) < new Date(fechaEntrada.value)) {
                alert("La fecha de salida no puede ser anterior a la fecha de entrada.");
                fechaSalida.value = ""; 
            }
        }
    }
});
</script>